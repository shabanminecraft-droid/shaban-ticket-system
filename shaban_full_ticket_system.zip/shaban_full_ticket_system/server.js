require('dotenv').config();
const express = require('express');
const fs = require('fs');
const path = require('path');
const nodemailer = require('nodemailer');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'shaban2025';
const DATA_DIR = path.join(__dirname, 'data');
const TICKETS_FILE = path.join(DATA_DIR, 'tickets.json');
const USERS_FILE = path.join(DATA_DIR, 'users.json');

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api/auth', rateLimit({ windowMs: 60 * 1000, max: 8 }));

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}
function writeJson(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}
function normalizeEmail(email) { return String(email || '').trim().toLowerCase(); }
function validEmail(email) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email); }
function userToken(email) { return jwt.sign({ role: 'user', email }, JWT_SECRET, { expiresIn: '30d' }); }
function adminToken() { return jwt.sign({ role: 'admin' }, JWT_SECRET, { expiresIn: '12h' }); }
function requireUser(req, res, next) {
  try {
    const token = (req.headers.authorization || '').replace('Bearer ', '');
    const data = jwt.verify(token, JWT_SECRET);
    if (data.role !== 'user' || !data.email) throw new Error('bad token');
    req.user = data;
    next();
  } catch { res.status(401).json({ error: 'Login required' }); }
}
function requireAdmin(req, res, next) {
  try {
    const token = (req.headers.authorization || '').replace('Bearer ', '');
    const data = jwt.verify(token, JWT_SECRET);
    if (data.role !== 'admin') throw new Error('bad token');
    next();
  } catch { res.status(401).json({ error: 'Admin login required' }); }
}

const transporter = nodemailer.createTransport({
  service: 'hotmail',
  auth: {
    user: process.env.EMAIL_USER || 'fivemshaban@hotmail.com',
    pass: process.env.EMAIL_PASS || ''
  }
});
async function sendLoginCode(email, code) {
  if (!process.env.EMAIL_PASS) {
    console.log(`[DEV LOGIN CODE] ${email}: ${code}`);
    return { devMode: true };
  }
  await transporter.sendMail({
    from: process.env.EMAIL_FROM || `Shaban.Dev Support <${process.env.EMAIL_USER || 'fivemshaban@hotmail.com'}>`,
    to: email,
    subject: 'Your Shaban.Dev login code',
    text: `Your Shaban.Dev login code is ${code}. It expires in 10 minutes.`,
    html: `<div style="font-family:Arial;background:#0a0c0f;color:#e8eaf0;padding:24px"><h2>Your Shaban.Dev login code</h2><p style="font-size:28px;letter-spacing:6px;color:#00e5ff"><b>${code}</b></p><p>This code expires in 10 minutes.</p></div>`
  });
  return { devMode: false };
}

app.post('/api/auth/request-code', async (req, res) => {
  const email = normalizeEmail(req.body.email);
  if (!validEmail(email)) return res.status(400).json({ error: 'Use a valid email' });
  const code = String(Math.floor(100000 + Math.random() * 900000));
  const hash = await bcrypt.hash(code, 10);
  const users = readJson(USERS_FILE, []);
  const idx = users.findIndex(u => u.email === email);
  const user = { email, codeHash: hash, codeExpires: Date.now() + 10 * 60 * 1000, createdAt: new Date().toISOString() };
  if (idx >= 0) users[idx] = { ...users[idx], ...user }; else users.push(user);
  writeJson(USERS_FILE, users);
  const sent = await sendLoginCode(email, code);
  res.json({ ok: true, message: sent.devMode ? 'Code created. Check server console because EMAIL_PASS is not set.' : 'Code sent to email.' });
});

app.post('/api/auth/verify-code', async (req, res) => {
  const email = normalizeEmail(req.body.email);
  const code = String(req.body.code || '').trim();
  const users = readJson(USERS_FILE, []);
  const user = users.find(u => u.email === email);
  if (!user || !user.codeHash || Date.now() > user.codeExpires) return res.status(400).json({ error: 'Code expired or invalid' });
  const ok = await bcrypt.compare(code, user.codeHash);
  if (!ok) return res.status(400).json({ error: 'Wrong code' });
  user.codeHash = null; user.codeExpires = null; user.lastLogin = new Date().toISOString();
  writeJson(USERS_FILE, users);
  res.json({ token: userToken(email), email });
});

app.post('/api/admin/login', (req, res) => {
  if (String(req.body.password || '') !== ADMIN_PASSWORD) return res.status(401).json({ error: 'Wrong password' });
  res.json({ token: adminToken() });
});

app.get('/api/me/tickets', requireUser, (req, res) => {
  const tickets = readJson(TICKETS_FILE, []);
  res.json(tickets.filter(t => t.email === req.user.email));
});
app.post('/api/tickets', requireUser, (req, res) => {
  const { name, discord, category, priority, subject, description } = req.body;
  if (![name, discord, category, priority, subject, description].every(x => String(x || '').trim())) return res.status(400).json({ error: 'Fill all fields' });
  const tickets = readJson(TICKETS_FILE, []);
  const ticket = {
    id: 'TKT-' + Date.now(), uid: uuidv4(), email: req.user.email,
    name: String(name).trim(), discord: String(discord).trim(), category, priority, subject: String(subject).trim(), description: String(description).trim(),
    status: 'Open', claimed: false, claimedBy: null, date: new Date().toISOString(), messages: []
  };
  tickets.unshift(ticket); writeJson(TICKETS_FILE, tickets); res.json(ticket);
});
app.post('/api/tickets/:id/messages', requireUser, (req, res) => {
  const tickets = readJson(TICKETS_FILE, []);
  const t = tickets.find(x => x.id === req.params.id && x.email === req.user.email);
  if (!t) return res.status(404).json({ error: 'Ticket not found' });
  if (!t.claimed) return res.status(400).json({ error: 'Wait until admin claims this ticket' });
  const text = String(req.body.text || '').trim(); if (!text) return res.status(400).json({ error: 'Message required' });
  t.messages.push({ from: 'user', text, date: new Date().toISOString() });
  writeJson(TICKETS_FILE, tickets); res.json(t);
});

app.get('/api/admin/tickets', requireAdmin, (req, res) => res.json(readJson(TICKETS_FILE, [])));
app.post('/api/admin/tickets/:id/claim', requireAdmin, (req, res) => {
  const tickets = readJson(TICKETS_FILE, []); const t = tickets.find(x => x.id === req.params.id);
  if (!t) return res.status(404).json({ error: 'Ticket not found' });
  t.claimed = true; t.claimedBy = 'Shaban'; t.status = 'In Progress';
  writeJson(TICKETS_FILE, tickets); res.json(t);
});
app.post('/api/admin/tickets/:id/status', requireAdmin, (req, res) => {
  const tickets = readJson(TICKETS_FILE, []); const t = tickets.find(x => x.id === req.params.id);
  if (!t) return res.status(404).json({ error: 'Ticket not found' });
  t.status = req.body.status || t.status; writeJson(TICKETS_FILE, tickets); res.json(t);
});
app.post('/api/admin/tickets/:id/messages', requireAdmin, (req, res) => {
  const tickets = readJson(TICKETS_FILE, []); const t = tickets.find(x => x.id === req.params.id);
  if (!t) return res.status(404).json({ error: 'Ticket not found' });
  if (!t.claimed) { t.claimed = true; t.claimedBy = 'Shaban'; t.status = 'In Progress'; }
  const text = String(req.body.text || '').trim(); if (!text) return res.status(400).json({ error: 'Message required' });
  t.messages.push({ from: 'admin', text, date: new Date().toISOString() });
  writeJson(TICKETS_FILE, tickets); res.json(t);
});
app.delete('/api/admin/tickets/:id', requireAdmin, (req, res) => {
  writeJson(TICKETS_FILE, readJson(TICKETS_FILE, []).filter(t => t.id !== req.params.id)); res.json({ ok: true });
});

app.listen(PORT, () => console.log(`Shaban ticket system running on http://localhost:${PORT}`));
