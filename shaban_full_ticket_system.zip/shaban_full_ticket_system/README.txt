SHABAN.DEV FULL TICKET SYSTEM

What is inside:
- public/index.html = user website + email login code + open ticket + my tickets + chat after claim
- public/admin.html = private admin dashboard + all tickets + claim + chat + status + delete
- server.js = backend/API that connects everyone together
- data/tickets.json = shared ticket database file
- data/users.json = login-code user file
- .env.example = settings template

IMPORTANT:
This needs Node.js hosting. It will NOT fully work as only static HTML because emails and shared tickets need a backend.

SETUP:
1. Install Node.js
2. Open this folder in terminal
3. Run: npm install
4. Copy .env.example and rename it to .env
5. Edit .env:
   EMAIL_USER=fivemshaban@hotmail.com
   EMAIL_PASS=your Hotmail/Microsoft app password
   ADMIN_PASSWORD=your admin password
   JWT_SECRET=make this a long random text
6. Run: npm start
7. Open: http://localhost:3000
8. Admin: http://localhost:3000/admin.html

EMAIL CODE LOGIN:
- User enters email
- System sends a 6 digit code from fivemshaban@hotmail.com
- User enters code and stays logged in automatically for 30 days

HOTMAIL APP PASSWORD:
You usually need a Microsoft app password, not your normal account password.
If EMAIL_PASS is empty, the login code will print in the server console for testing.

DEPLOYMENT:
Use a Node.js host like Render, Railway, VPS, or your own server.
Static hosts like GitHub Pages / Netlify static only will not send email or share tickets.
